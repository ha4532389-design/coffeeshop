import React from 'react';
import { Product } from '../types';

interface ProductDetailProps {
  product: Product;
  onClose: () => void;
  onAddToCart: (product: Product, quantity: number) => void;
}

const roastColors: Record<string, string> = {
  light: 'bg-amber-100 text-amber-800 border-amber-200',
  medium: 'bg-orange-100 text-orange-800 border-orange-200',
  dark: 'bg-stone-200 text-stone-800 border-stone-300',
};

const ProductDetail: React.FC<ProductDetailProps> = ({ product, onClose, onAddToCart }) => {
  const [quantity, setQuantity] = React.useState(1);

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4" onClick={onClose}>
      {/* Backdrop */}
      <div className="absolute inset-0 bg-black/60 backdrop-blur-sm" />
      
      {/* Modal */}
      <div
        className="relative w-full max-w-3xl max-h-[90vh] bg-white rounded-3xl shadow-2xl overflow-hidden animate-in"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Close button */}
        <button
          onClick={onClose}
          className="absolute top-4 right-4 z-10 w-10 h-10 bg-white/90 backdrop-blur-sm rounded-full flex items-center justify-center shadow-md hover:bg-white transition-colors"
        >
          <svg className="w-5 h-5 text-amber-900" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
          </svg>
        </button>

        <div className="flex flex-col md:flex-row max-h-[90vh] overflow-y-auto">
          {/* Image */}
          <div className="md:w-1/2 aspect-square md:aspect-auto md:min-h-full relative shrink-0">
            <img
              src={product.image}
              alt={product.name}
              className="w-full h-full object-cover"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-black/20 to-transparent md:bg-gradient-to-r" />
          </div>

          {/* Content */}
          <div className="md:w-1/2 p-6 sm:p-8 flex flex-col">
            <div className="flex-1">
              {/* Category badge */}
              <span className="inline-block px-3 py-1 bg-amber-50 text-amber-700 text-xs font-medium rounded-full border border-amber-200 mb-3">
                {product.category === 'single-origin' ? 'Single Origin' : product.category.charAt(0).toUpperCase() + product.category.slice(1)}
              </span>

              <h2 className="font-serif text-2xl sm:text-3xl font-bold text-amber-950 mb-1">{product.name}</h2>
              <p className="text-amber-600 text-sm mb-4">{product.origin}</p>

              {/* Rating */}
              <div className="flex items-center gap-2 mb-4">
                <div className="flex items-center gap-0.5">
                  {[...Array(5)].map((_, i) => (
                    <svg
                      key={i}
                      className={`w-4 h-4 ${i < Math.floor(product.rating) ? 'text-amber-400' : 'text-amber-200'}`}
                      fill="currentColor"
                      viewBox="0 0 20 20"
                    >
                      <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z" />
                    </svg>
                  ))}
                </div>
                <span className="text-sm text-amber-700 font-medium">{product.rating}/5</span>
              </div>

              {/* Description */}
              <p className="text-amber-800/80 text-sm leading-relaxed mb-5">{product.description}</p>

              {/* Details grid */}
              <div className="grid grid-cols-2 gap-3 mb-5">
                <div className="bg-amber-50/80 rounded-xl p-3 border border-amber-100">
                  <p className="text-[11px] uppercase tracking-wider text-amber-500 font-medium">Roast</p>
                  <span className={`inline-block mt-1 px-2 py-0.5 rounded-md text-xs font-medium border ${roastColors[product.roast]}`}>
                    {product.roast.charAt(0).toUpperCase() + product.roast.slice(1)}
                  </span>
                </div>
                <div className="bg-amber-50/80 rounded-xl p-3 border border-amber-100">
                  <p className="text-[11px] uppercase tracking-wider text-amber-500 font-medium">Weight</p>
                  <p className="text-sm font-semibold text-amber-900 mt-1">{product.weight}</p>
                </div>
              </div>

              {/* Flavor notes */}
              <div className="mb-6">
                <p className="text-xs uppercase tracking-wider text-amber-500 font-medium mb-2">Flavor Notes</p>
                <div className="flex flex-wrap gap-2">
                  {product.notes.map((note) => (
                    <span key={note} className="px-3 py-1.5 bg-gradient-to-r from-amber-50 to-orange-50 text-amber-800 text-sm rounded-lg border border-amber-200/60">
                      {note}
                    </span>
                  ))}
                </div>
              </div>
            </div>

            {/* Price and Add to Cart */}
            <div className="border-t border-amber-100 pt-5">
              <div className="flex items-center justify-between mb-4">
                <div>
                  <span className="text-3xl font-bold text-amber-950">${product.price.toFixed(2)}</span>
                  <span className="text-sm text-amber-500 ml-1">/ {product.weight}</span>
                </div>
                
                {/* Quantity selector */}
                <div className="flex items-center gap-1 bg-amber-50 rounded-xl border border-amber-200/60 p-1">
                  <button
                    onClick={() => setQuantity(Math.max(1, quantity - 1))}
                    className="w-8 h-8 flex items-center justify-center rounded-lg hover:bg-amber-100 text-amber-700 transition-colors"
                  >
                    <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M20 12H4" />
                    </svg>
                  </button>
                  <span className="w-8 text-center text-sm font-semibold text-amber-900">{quantity}</span>
                  <button
                    onClick={() => setQuantity(quantity + 1)}
                    className="w-8 h-8 flex items-center justify-center rounded-lg hover:bg-amber-100 text-amber-700 transition-colors"
                  >
                    <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 4v16m8-8H4" />
                    </svg>
                  </button>
                </div>
              </div>

              <button
                onClick={() => {
                  onAddToCart(product, quantity);
                  onClose();
                }}
                className="w-full py-3.5 bg-amber-900 hover:bg-amber-800 text-white font-medium rounded-xl shadow-lg shadow-amber-900/20 hover:shadow-xl transition-all active:scale-[0.98]"
              >
                Add to Cart — ${(product.price * quantity).toFixed(2)}
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ProductDetail;
