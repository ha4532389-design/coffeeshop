import React, { useState } from 'react';
import { CartItem } from '../types';

interface CheckoutProps {
  cartItems: CartItem[];
  onClose: () => void;
  onComplete: () => void;
}

const Checkout: React.FC<CheckoutProps> = ({ cartItems, onClose, onComplete }) => {
  const [step, setStep] = useState<'form' | 'processing' | 'success'>('form');
  const [formData, setFormData] = useState({
    email: '',
    name: '',
    address: '',
    city: '',
    zip: '',
    cardNumber: '',
    expiry: '',
    cvv: '',
  });

  const subtotal = cartItems.reduce((sum, item) => sum + item.product.price * item.quantity, 0);
  const shipping = subtotal > 50 ? 0 : 5.99;
  const total = subtotal + shipping;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setStep('processing');
    
    // Simulate processing
    setTimeout(() => {
      setStep('success');
    }, 2000);
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  if (step === 'success') {
    return (
      <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
        <div className="absolute inset-0 bg-black/60 backdrop-blur-sm" />
        <div className="relative w-full max-w-md bg-white rounded-3xl shadow-2xl p-8 text-center">
          <div className="w-20 h-20 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-5">
            <svg className="w-10 h-10 text-green-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
            </svg>
          </div>
          <h2 className="font-serif text-2xl font-bold text-amber-950 mb-2">Order Confirmed!</h2>
          <p className="text-amber-600 mb-2">Thank you for your purchase.</p>
          <p className="text-sm text-amber-500 mb-6">
            Order #EB-{Math.random().toString(36).substr(2, 8).toUpperCase()}
          </p>
          <div className="bg-amber-50 rounded-xl p-4 mb-6 text-left">
            <p className="text-xs uppercase tracking-wider text-amber-500 font-medium mb-2">Order Summary</p>
            {cartItems.map((item) => (
              <div key={item.product.id} className="flex justify-between text-sm py-1">
                <span className="text-amber-800">{item.product.name} × {item.quantity}</span>
                <span className="font-medium text-amber-900">${(item.product.price * item.quantity).toFixed(2)}</span>
              </div>
            ))}
            <div className="border-t border-amber-200/60 mt-2 pt-2 flex justify-between">
              <span className="font-semibold text-amber-950">Total</span>
              <span className="font-bold text-amber-950">${total.toFixed(2)}</span>
            </div>
          </div>
          <button
            onClick={onComplete}
            className="w-full py-3.5 bg-amber-900 hover:bg-amber-800 text-white font-medium rounded-xl shadow-lg transition-all"
          >
            Continue Shopping
          </button>
        </div>
      </div>
    );
  }

  if (step === 'processing') {
    return (
      <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
        <div className="absolute inset-0 bg-black/60 backdrop-blur-sm" />
        <div className="relative w-full max-w-sm bg-white rounded-3xl shadow-2xl p-8 text-center">
          <div className="w-16 h-16 border-4 border-amber-200 border-t-amber-800 rounded-full animate-spin mx-auto mb-5" />
          <h2 className="font-serif text-xl font-bold text-amber-950 mb-2">Processing Order</h2>
          <p className="text-sm text-amber-600">Please wait while we confirm your order...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
      <div className="absolute inset-0 bg-black/60 backdrop-blur-sm" onClick={onClose} />
      <div className="relative w-full max-w-2xl max-h-[90vh] bg-white rounded-3xl shadow-2xl overflow-hidden">
        {/* Header */}
        <div className="flex items-center justify-between p-5 border-b border-amber-100">
          <h2 className="font-serif text-xl font-bold text-amber-950">Checkout</h2>
          <button
            onClick={onClose}
            className="w-9 h-9 flex items-center justify-center rounded-full hover:bg-amber-50 text-amber-600 transition-colors"
          >
            <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
            </svg>
          </button>
        </div>

        <div className="flex flex-col md:flex-row max-h-[calc(90vh-80px)] overflow-y-auto">
          {/* Form */}
          <form onSubmit={handleSubmit} className="flex-1 p-5 sm:p-6 space-y-5">
            {/* Contact */}
            <div>
              <h3 className="text-sm font-semibold text-amber-900 mb-3 flex items-center gap-2">
                <span className="w-6 h-6 bg-amber-100 rounded-full flex items-center justify-center text-xs font-bold text-amber-700">1</span>
                Contact Information
              </h3>
              <div className="space-y-3">
                <input
                  type="email"
                  name="email"
                  placeholder="Email address"
                  value={formData.email}
                  onChange={handleChange}
                  required
                  className="w-full px-4 py-2.5 bg-amber-50/50 border border-amber-200/60 rounded-xl text-sm text-amber-950 placeholder-amber-400/60 focus:outline-none focus:ring-2 focus:ring-amber-400/40 focus:border-amber-400 transition-all"
                />
                <input
                  type="text"
                  name="name"
                  placeholder="Full name"
                  value={formData.name}
                  onChange={handleChange}
                  required
                  className="w-full px-4 py-2.5 bg-amber-50/50 border border-amber-200/60 rounded-xl text-sm text-amber-950 placeholder-amber-400/60 focus:outline-none focus:ring-2 focus:ring-amber-400/40 focus:border-amber-400 transition-all"
                />
              </div>
            </div>

            {/* Shipping */}
            <div>
              <h3 className="text-sm font-semibold text-amber-900 mb-3 flex items-center gap-2">
                <span className="w-6 h-6 bg-amber-100 rounded-full flex items-center justify-center text-xs font-bold text-amber-700">2</span>
                Shipping Address
              </h3>
              <div className="space-y-3">
                <input
                  type="text"
                  name="address"
                  placeholder="Street address"
                  value={formData.address}
                  onChange={handleChange}
                  required
                  className="w-full px-4 py-2.5 bg-amber-50/50 border border-amber-200/60 rounded-xl text-sm text-amber-950 placeholder-amber-400/60 focus:outline-none focus:ring-2 focus:ring-amber-400/40 focus:border-amber-400 transition-all"
                />
                <div className="grid grid-cols-2 gap-3">
                  <input
                    type="text"
                    name="city"
                    placeholder="City"
                    value={formData.city}
                    onChange={handleChange}
                    required
                    className="w-full px-4 py-2.5 bg-amber-50/50 border border-amber-200/60 rounded-xl text-sm text-amber-950 placeholder-amber-400/60 focus:outline-none focus:ring-2 focus:ring-amber-400/40 focus:border-amber-400 transition-all"
                  />
                  <input
                    type="text"
                    name="zip"
                    placeholder="ZIP code"
                    value={formData.zip}
                    onChange={handleChange}
                    required
                    className="w-full px-4 py-2.5 bg-amber-50/50 border border-amber-200/60 rounded-xl text-sm text-amber-950 placeholder-amber-400/60 focus:outline-none focus:ring-2 focus:ring-amber-400/40 focus:border-amber-400 transition-all"
                  />
                </div>
              </div>
            </div>

            {/* Payment */}
            <div>
              <h3 className="text-sm font-semibold text-amber-900 mb-3 flex items-center gap-2">
                <span className="w-6 h-6 bg-amber-100 rounded-full flex items-center justify-center text-xs font-bold text-amber-700">3</span>
                Payment (Simulated)
              </h3>
              <div className="space-y-3">
                <input
                  type="text"
                  name="cardNumber"
                  placeholder="Card number"
                  value={formData.cardNumber}
                  onChange={handleChange}
                  required
                  maxLength={19}
                  className="w-full px-4 py-2.5 bg-amber-50/50 border border-amber-200/60 rounded-xl text-sm text-amber-950 placeholder-amber-400/60 focus:outline-none focus:ring-2 focus:ring-amber-400/40 focus:border-amber-400 transition-all"
                />
                <div className="grid grid-cols-2 gap-3">
                  <input
                    type="text"
                    name="expiry"
                    placeholder="MM/YY"
                    value={formData.expiry}
                    onChange={handleChange}
                    required
                    maxLength={5}
                    className="w-full px-4 py-2.5 bg-amber-50/50 border border-amber-200/60 rounded-xl text-sm text-amber-950 placeholder-amber-400/60 focus:outline-none focus:ring-2 focus:ring-amber-400/40 focus:border-amber-400 transition-all"
                  />
                  <input
                    type="text"
                    name="cvv"
                    placeholder="CVV"
                    value={formData.cvv}
                    onChange={handleChange}
                    required
                    maxLength={4}
                    className="w-full px-4 py-2.5 bg-amber-50/50 border border-amber-200/60 rounded-xl text-sm text-amber-950 placeholder-amber-400/60 focus:outline-none focus:ring-2 focus:ring-amber-400/40 focus:border-amber-400 transition-all"
                  />
                </div>
              </div>
              <p className="text-xs text-amber-400 mt-2 flex items-center gap-1">
                <svg className="w-3 h-3" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2zm10-10V7a4 4 0 00-8 0v4h8z" />
                </svg>
                This is a simulated checkout. No real payment is processed.
              </p>
            </div>

            <button
              type="submit"
              className="w-full py-3.5 bg-amber-900 hover:bg-amber-800 text-white font-medium rounded-xl shadow-lg shadow-amber-900/20 hover:shadow-xl transition-all active:scale-[0.98]"
            >
              Place Order — ${total.toFixed(2)}
            </button>
          </form>

          {/* Order Summary */}
          <div className="md:w-72 bg-amber-50/50 border-t md:border-t-0 md:border-l border-amber-100 p-5">
            <h3 className="text-sm font-semibold text-amber-900 mb-3">Order Summary</h3>
            <div className="space-y-3">
              {cartItems.map((item) => (
                <div key={item.product.id} className="flex gap-2">
                  <img
                    src={item.product.image}
                    alt={item.product.name}
                    className="w-10 h-10 rounded-lg object-cover shrink-0"
                  />
                  <div className="flex-1 min-w-0">
                    <p className="text-xs font-medium text-amber-900 truncate">{item.product.name}</p>
                    <p className="text-xs text-amber-500">Qty: {item.quantity}</p>
                  </div>
                  <span className="text-xs font-semibold text-amber-900 shrink-0">
                    ${(item.product.price * item.quantity).toFixed(2)}
                  </span>
                </div>
              ))}
            </div>
            <div className="border-t border-amber-200/60 mt-4 pt-3 space-y-1.5">
              <div className="flex justify-between text-xs">
                <span className="text-amber-600">Subtotal</span>
                <span className="text-amber-900">${subtotal.toFixed(2)}</span>
              </div>
              <div className="flex justify-between text-xs">
                <span className="text-amber-600">Shipping</span>
                <span className="text-amber-900">{shipping === 0 ? 'Free' : `$${shipping.toFixed(2)}`}</span>
              </div>
              <div className="flex justify-between text-sm font-bold pt-1 border-t border-amber-200/60">
                <span className="text-amber-950">Total</span>
                <span className="text-amber-950">${total.toFixed(2)}</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Checkout;
