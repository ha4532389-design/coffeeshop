import React from 'react';
import { Category } from '../types';

interface CategoryFilterProps {
  selectedCategory: Category;
  onCategoryChange: (category: Category) => void;
}

const categories: { value: Category; label: string; icon: string }[] = [
  { value: 'all', label: 'All Coffees', icon: '☕' },
  { value: 'single-origin', label: 'Single Origin', icon: '🌍' },
  { value: 'blend', label: 'Blends', icon: '🎨' },
  { value: 'espresso', label: 'Espresso', icon: '⚡' },
  { value: 'decaf', label: 'Decaf', icon: '🌙' },
];

const CategoryFilter: React.FC<CategoryFilterProps> = ({ selectedCategory, onCategoryChange }) => {
  return (
    <div className="flex gap-2 overflow-x-auto pb-2 scrollbar-hide">
      {categories.map((cat) => (
        <button
          key={cat.value}
          onClick={() => onCategoryChange(cat.value)}
          className={`flex items-center gap-2 px-4 py-2.5 rounded-xl text-sm font-medium whitespace-nowrap transition-all ${
            selectedCategory === cat.value
              ? 'bg-amber-900 text-amber-50 shadow-md shadow-amber-900/20'
              : 'bg-amber-50 text-amber-800 hover:bg-amber-100 border border-amber-200/60'
          }`}
        >
          <span className="text-base">{cat.icon}</span>
          <span>{cat.label}</span>
        </button>
      ))}
    </div>
  );
};

export default CategoryFilter;
