export interface Product {
  id: number;
  name: string;
  origin: string;
  category: 'single-origin' | 'blend' | 'espresso' | 'decaf';
  price: number;
  weight: string;
  roast: 'light' | 'medium' | 'dark';
  description: string;
  notes: string[];
  image: string;
  rating: number;
  inStock: boolean;
}

export interface CartItem {
  product: Product;
  quantity: number;
}

export type Category = 'all' | 'single-origin' | 'blend' | 'espresso' | 'decaf';
